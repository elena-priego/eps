color1 <- c("#006C67", "#F56258", "#FFB100", "#002A47")
color2 <- c("#3376BC", "#C14D7C", "#F4A82C", "#003015")
color3 <- c("#B35DCC", "#EFCD4A", "#0B7EF3", "#332B02")
color4 <- c("#5ABCC4", "#FFC533", "#FF5452", "#002324")
color5 <- c("#6198FF", "#89B449", "#E69682", "#001F33")
color6 <- c("#FE9A84", "#08808E", "#BEC74B", "#1B0038")
shape1 <- c(0, 7) #cuadrado y cuadrado tachado
shape2 <- c(16, 4) #circulo mediano y cruz
shape3 <- c(19, 17) # circulo grande y triangulo agrande
color_eps <- c(color1, color2, color3, color4, color5, color6)
shape_eps <- c(shape1, shape2, shape3)

# save(color_eps, file = "data/colore_eps.rda")
# save(shape_eps, file = "data/shape_eps.rda")

