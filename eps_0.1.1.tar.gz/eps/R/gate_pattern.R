#' List of replacements for facs analysis
#'
#' Named list containing common replacement for facs analysis
#'
#' @format Named list with the desired replacements
#'
#' @keywords data
"gate_pattern"
